LGPL relinking material for citation HTML kernel.
Run: sh link.sh /path/to/wasi-sdk-34.0-x86_64-linux [replacement-libiconv.a] [output.wasm]
The default library is the original GNU libiconv 1.17 converter.
Unmodified complete converter source ships alongside as sources/libiconv-1.17.tar.gz.
The source recipe build-html-kernel.py records its configuration and archive digest.
The authored locale_charset glue is compiled into kernel.o; kernel.c is shipped beside the asset.
Complete original archives retain symbol indices and debug information; the receipt separately records linked members.
All retained license texts accompany these objects in licenses/.
No signing key or proprietary linker is required. A modified engine may update its source hash guard.
