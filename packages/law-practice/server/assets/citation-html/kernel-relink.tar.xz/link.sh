#!/bin/sh
set -eu
cd "$(dirname "$0")"
sdk_dir=$1
replacement_library=${2:-./libiconv.a}
output_file=${3:-./kernel.wasm}
"$sdk_dir/bin/clang" --target=wasm32-wasip1 --no-wasm-opt -O2 -mexec-model=reactor -nostdlib ./crt1-reactor.o ./kernel.o ./libxml2.a "$replacement_library" ./libc.a ./libclang_rt.builtins.a -Wl,--export=html_clean -Wl,--export=html_output -Wl,--export=html_output_length -Wl,--export=html_output_units -Wl,--export=html_release -Wl,--export=html_version -Wl,--export=html_iconv_version -Wl,--export=html_iconv_inventory -Wl,--export=html_iconv_inventory_length -Wl,--export=malloc -Wl,--export=free -Wl,--max-memory=536870912 -o "$output_file"
